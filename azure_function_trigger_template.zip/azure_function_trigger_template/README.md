Reference: https://learn.microsoft.com/en-us/azure/azure-functions/functions-deploy-container-apps?tabs=acr%2Ccmd&pivots=programming-language-python

# Existing Container in AWS ECR
cleaning
heatmap
heatmap-stage
mapmatch
raw
subzoning

# function trigger template
Here are some of the available templates you can choose from:
<!-->
HTTP trigger
Timer trigger
Blob trigger
Queue trigger
Event Hub trigger
Service Bus Queue trigger
Service Bus Topic trigger
Cosmos DB trigger
Azure Event Grid trigger
RabbitMQ trigger
Kafka trigger
IoT Hub trigger
-->


# build container - TODO: change <cleaning> to your container name
docker build --tag acrsmartbfa0001.azurecr.io/cleaning:latest .
docker images

# Publish the container image to a registry
# TODO: change <acrsmartbfa0001> to your ACR
az acr login --name acrsmartbfa0001

docker images

# docker tag cleaning-app acrsmartbfa0001.azurecr.io/cleaning-app:v1
# docker tag <DOCKER_ID>/azurefunctionsimage:v1.0.0 <LOGIN_SERVER>/azurefunctionsimage:v1.0.0

docker push acrsmartbfa0001.azurecr.io/cleaning:latest


# Deployment Steps

az extension add --name containerapp --upgrade -y
az provider register --namespace Microsoft.Web 
az provider register --namespace Microsoft.App 
az provider register --namespace Microsoft.OperationalInsights 


az group create --name rg-smartbfa-funcapps --location southeastasia
az containerapp env create --name caenv-smartbfa0001 --enable-workload-profiles --resource-group rg-smartbfa-funcapps --location southeastasia

az storage account create --name stsmartbfasambaxx1 --location southeastasia --resource-group rg-smartbfa-funcapps --sku Standard_LRS --allow-blob-public-access true --min-tls-version TLS1_2

# TODO: ** IMPORTANT
# IAM - grant your email address (e.g. thiamsoontan@microsoft.com) to acr pull permission
# TODO: 
# change <cleaning> to your container name
# change <acrsmartbfa0001> to your ACR name
# change <func-samba-cleaning-0001> to your azure function name

az functionapp create --name func-samba-cleaning-0001 \
--storage-account stsmartbfasambaxx1 \
--environment caenv-smartbfa0001 \
--workload-profile-name "Consumption" \
--resource-group rg-smartbfa-funcapps \
--functions-version 4 \
--runtime python \
--image acrsmartbfa0001.azurecr.io/cleaning:latest \
--assign-identity 

# grant the azure function to be able to PULL from ACR
FUNCTION_APP_ID=$(az functionapp identity assign --name func-smartbfa0001 --resource-group rg-smartbfa-funcapps --query principalId --output tsv)
ACR_ID=$(az acr show --name acrsmartbfa0001 --query id --output tsv)
az role assignment create --assignee $FUNCTION_APP_ID --role AcrPull --scope $ACR_ID


az functionapp function show --resource-group rg-smartbfa-funcapps --name func-smartbfa0001 --function-name HttpExample --query invokeUrlTemplate



