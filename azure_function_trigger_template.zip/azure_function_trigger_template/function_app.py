import azure.functions as func
import datetime
import json
import logging
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
import urllib.parse
from subprocess import call
import os
import tempfile

# source: storage account samba-rawdata/proc/gps/xxx.csv.gz
# destination: storage account samba-rawdata/clean/xxx.csv

app = func.FunctionApp()

# TODO: change your blob storage path here "samba-rawdata/proc/gps/" to <your storage account blob path>
@app.blob_trigger(arg_name="myblob", path="samba-rawdata/proc/gps/{name}",
                               connection="AzureWebJobsStorage") 

# TODO: change <SambaRawdataProcGpsBlobTrigger> to your function name here 
def RawBlobTrigger(myblob: func.InputStream):
    logging.info(f"Python blob trigger function processed blob "
                f"Name: {myblob.name} "
                f"Blob Size: {myblob.length} bytes")
    
    """Get raw file from Azure Blob Storage and process it."""
